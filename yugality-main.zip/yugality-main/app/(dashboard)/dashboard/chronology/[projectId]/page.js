"use client";

import { useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { Filter, FileText, Search, Plus, Trash2, ChevronLeft } from "lucide-react";
import ChronologyTable from "@/app/components/chronology/ChronologyTable";

const projectsData = {
  "project-vermiculite-25072025": {
    name: "Project Vermiculite - 25/07/2025",
    chronologies: [
      { id: 1, date: "October 5, 1960", event: "Hakam Singh agreed to perform certain construction work for M/S. Gammon (India) Ltd. under a written tender. The tender included clauses specifying arbitration and jurisdiction, stating that disputes would be referred to arbitration under the Arbitration Act of 1940 and that the courts in Bombay would have jurisdiction.", source: "Hakam Singh V. Gammon (India) Ltd.", issue: "Order 7 Rule 10- Territorial jurisdiction", page: 2 },
      { id: 2, date: "May 4, 1961", event: "The decision in the case of Hira Lal Patni v. Kali Nath was delivered by the Supreme Court of India. The bench comprised B.P. Sinha, C.J., and Justices K. Subba Rao, Raghubar Dayal, and J.R. Mudholkar. This case addressed the nature and scope of Section 21 of the Civil Procedure Code, 1908.", source: "Hira Lal Patni V. Kali Nath, Narsingh Das", issue: "Order 7 Rule 10- Territorial jurisdiction", page: 3 },
      { id: 3, date: "March 12, 1965", event: "The Supreme Court delivered its judgment in the matter of State of Rajasthan v. Nathu Lal, addressing the question of limitation periods applicable to suits filed by the government. The court held that the general law of limitation applies equally to the government as to private parties unless specifically exempted by statute.", source: "State of Rajasthan V. Nathu Lal", issue: "Limitation Act - Government Suits", page: 5 },
    ],
  },
  "strawberryfrog-30052025": {
    name: "Strawberryfrog - 30/05/2025",
    chronologies: [
      { id: 1, date: "January 10, 2024", event: "Initial agreement signed between Strawberryfrog Inc. and the client for brand strategy consulting services. The agreement outlined deliverables, timelines, and payment schedules for a 6-month engagement.", source: "Service Agreement 2024", issue: "Contract Formation", page: 1 },
      { id: 2, date: "March 22, 2024", event: "First milestone deliverable submitted. Client raised objections regarding the scope of work, claiming the deliverables did not match the agreed specifications in Annexure B of the contract.", source: "Email Correspondence - March 2024", issue: "Scope Dispute", page: 4 },
    ],
  },
  "acquisition-agreements": {
    name: "Acquisition Agreements",
    chronologies: [
      { id: 1, date: "February 5, 2025", event: "Letter of Intent signed between acquiring company and target company for the proposed acquisition of 100% shareholding. The LOI outlined the proposed purchase price, due diligence timeline, and exclusivity period of 60 days.", source: "Letter of Intent - Feb 2025", issue: "Acquisition - LOI", page: 1 },
      { id: 2, date: "March 1, 2025", event: "Due diligence process commenced. Legal, financial, and operational teams began review of target company's records. Several material discrepancies were identified in the financial statements for FY 2023-24.", source: "Due Diligence Report", issue: "Due Diligence Findings", page: 8 },
    ],
  },
};

export default function ProjectDetailPage() {
  const router = useRouter();
  const { projectId } = useParams();

  const project = projectsData[projectId] || { name: projectId, chronologies: [] };
  const [chronologies, setChronologies] = useState(project.chronologies);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRows, setSelectedRows] = useState([]);

  const filtered = chronologies.filter(c =>
    c.event.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.source.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleRow = (id) => setSelectedRows(prev => prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]);
  const toggleAll = () => setSelectedRows(selectedRows.length === chronologies.length ? [] : chronologies.map(c => c.id));

  return (
    <div className="min-h-screen px-4 sm:px-6 md:px-10 py-6 sm:py-8 md:py-10">
      
      {/* Header */}
      <div className="mb-5 sm:mb-6 flex flex-col gap-4 sm:gap-6">
        <div className="flex items-start gap-3 sm:gap-4">
          <button onClick={() => router.push("/dashboard/chronology")} className="w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center rounded-xl border border-colordark/[0.08] text-colordark/50 hover:text-blue-from hover:border-blue-from/40 transition-all shrink-0 cursor-pointer shadow-sm mt-0.5">
            <ChevronLeft size={18} strokeWidth={2} />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="text-[1.125rem] sm:text-[1.375rem] md:text-[1.75rem] font-semibold text-colordark tracking-[-0.02em] leading-tight break-words">
              {project.name}
            </h1>
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[0.8125rem] sm:text-[0.875rem] text-colordark/45 mt-1 overflow-hidden">
              <span className="cursor-pointer hover:text-blue-from transition-colors whitespace-nowrap" onClick={() => router.push("/dashboard/chronology")}>Chronology</span>
              <span>/</span>
              <span className="truncate">{project.name}</span>
            </div>
          </div>
        </div>

        {/* Action buttons — wrap on mobile */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-2.5">
          {selectedRows.length > 0 && (
            <button onClick={() => { setChronologies(chronologies.filter(c => !selectedRows.includes(c.id))); setSelectedRows([]); }}
              className="flex items-center gap-1.5 px-3 sm:px-3.5 h-9 text-[0.8125rem] font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-xl transition-all cursor-pointer whitespace-nowrap">
              <Trash2 size={15} strokeWidth={2} />Delete
            </button>
          )}
          <button className="flex items-center gap-1.5 px-3 sm:px-3.5 h-9 text-[0.8125rem] font-medium text-colordark/60 hover:text-colordark border border-colordark/[0.08] hover:border-colordark/15 rounded-xl transition-all cursor-pointer shadow-sm whitespace-nowrap">
            <Plus size={15} strokeWidth={2} />Add Issues
          </button>
          <button className="flex items-center gap-1.5 px-3 sm:px-4 h-9 text-[0.8125rem] font-semibold text-white bg-gradient-to-r from-blue-from to-blue-to hover:shadow-[0_4px_15px_-3px_rgba(59,130,246,0.4)] rounded-xl transition-all cursor-pointer shadow-sm whitespace-nowrap">
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <span className="hidden sm:inline">Consolidate</span> Dates
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-5 sm:gap-6">
        
        {/* Table Container Card */}
        <div className="rounded-2xl border border-colordark/[0.06] overflow-hidden bg-transparent">
          
          {/* Toolbar */}
          <div className="px-4 sm:px-5 py-3 sm:py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 border-b border-colordark/[0.06]">
            <div className="flex items-center gap-2 sm:gap-2.5">
              <button className="flex items-center gap-1.5 px-3 sm:px-3.5 h-9 text-[0.8125rem] font-medium text-colordark/60 hover:text-colordark border border-colordark/[0.08] hover:border-colordark/15 rounded-xl transition-all cursor-pointer">
                <Filter size={14} strokeWidth={2} />Filters
              </button>
              <button className="flex items-center gap-1.5 px-3 sm:px-3.5 h-9 text-[0.8125rem] font-medium text-colordark/60 hover:text-colordark border border-colordark/[0.08] hover:border-colordark/15 rounded-xl transition-all cursor-pointer">
                <FileText size={14} strokeWidth={2} /><span className="hidden xs:inline">Documents</span><span className="xs:hidden">Docs</span>
              </button>
            </div>
            
            <div className="flex items-center">
              <div className="relative group w-full sm:w-[220px]">
                <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-colordark/30 group-focus-within:text-blue-from transition-colors" strokeWidth={2} />
                <input type="text" placeholder="Search chronologies" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-9 pl-9 pr-4 text-[0.8125rem] text-colordark placeholder:text-colordark/35 border border-colordark/[0.08] rounded-xl focus:outline-none focus:border-blue-from/40 focus:shadow-[0_0_0_3px_rgba(59,130,246,0.06)] transition-all cursor-text" />
              </div>
            </div>
          </div>

          <ChronologyTable
            filtered={filtered}
            chronologies={chronologies}
            selectedRows={selectedRows}
            toggleRow={toggleRow}
            toggleAll={toggleAll}
            onDelete={(id) => setChronologies(chronologies.filter(c => c.id !== id))}
          />
        </div>
      </div>
    </div>
  );
}
