"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";
import CriticalDeadlines from "@/app/components/dashboard/CriticalDeadlines";
import TodaysTasks from "@/app/components/dashboard/TodaysTasks";
import RecentActivity from "@/app/components/dashboard/RecentActivity";
import UpcomingHearings from "@/app/components/dashboard/UpcomingHearings";
import MiniCalendar from "@/app/components/dashboard/MiniCalendar";
import QuickActionsFAB from "@/app/components/dashboard/QuickActionsFAB";
import StatsRow from "@/app/components/dashboard/StatsRow";
import DashboardTopBar from "@/app/components/dashboard/DashboardTopBar";
import LatestNews from "@/app/components/dashboard/LatestNews";

export default function Dashboard() {
  const [userName, setUserName] = useState("");

  useEffect(() => {
    const getUser = async () => {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const firstName =
          user.user_metadata?.first_name ||
          user.user_metadata?.firstName ||
          user.user_metadata?.full_name?.split(" ")[0] ||
          user.email?.split("@")[0];
        if (firstName) setUserName(firstName.charAt(0).toUpperCase() + firstName.slice(1));
      }
    };
    getUser();
  }, []);

  return (
    <div className="min-h-screen">
      <div className="px-6 md:px-10 py-8 md:py-10">
        <DashboardTopBar userName={userName} />

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6">
          {/* Main Column */}
          <div className="flex flex-col gap-6">
            <UpcomingHearings />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <TodaysTasks />
              <CriticalDeadlines />
            </div>

            <RecentActivity />
          </div>

          {/* Sidebar Column */}
          <div className="flex flex-col gap-6">
            <MiniCalendar />
            <LatestNews />
          </div>
        </div>
      </div>
      
      <QuickActionsFAB />
    </div>
  );
}

