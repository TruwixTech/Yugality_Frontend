"use client";

import { useState, useEffect } from "react";
import CalendarHeader from "@/app/components/calendar/CalendarHeader";
import DayView from "@/app/components/calendar/DayView";
import WeekView from "@/app/components/calendar/WeekView";
import MonthView from "@/app/components/calendar/MonthView";
import EventDetailsPanel from "@/app/components/calendar/EventDetailsPanel";
import DayEventsPanel from "@/app/components/calendar/DayEventsPanel";
import AddEventModal from "@/app/components/calendar/AddEventModal";
import { getEventsForDate, getWeekDays, getHeaderText, isSameDay } from "@/app/components/calendar/calendarUtils";

const initialEvents = [
  { id: 1, title: "Court Hearing - Case #2026-001", date: new Date(2026, 2, 24), time: "10:00", endTime: "11:30", location: "District Court, Room 301", type: "hearing" },
  { id: 2, title: "Client Meeting - Sarah Johnson", date: new Date(2026, 2, 24), time: "14:00", endTime: "15:00", location: "Office Conference Room", type: "meeting" },
  { id: 3, title: "Document Review", date: new Date(2026, 2, 25), time: "09:00", endTime: "10:30", location: "Law Firm Office", type: "task" },
  { id: 4, title: "Arbitration Hearing", date: new Date(2026, 2, 26), time: "11:00", endTime: "13:00", location: "Arbitration Center", type: "hearing" },
  { id: 5, title: "Contract Signing - ABC Corp", date: new Date(2026, 2, 27), time: "15:00", endTime: "16:00", location: "Client Office", type: "meeting" },
  { id: 6, title: "Appeal Filing Deadline", date: new Date(2026, 2, 28), time: "17:00", endTime: "17:00", location: "High Court Registry", type: "deadline" },
  { id: 7, title: "Witness Deposition", date: new Date(2026, 2, 30), time: "10:30", endTime: "12:00", location: "Law Office, Room 205", type: "hearing" },
  { id: 8, title: "Legal Research", date: new Date(2026, 3, 1), time: "14:00", endTime: "16:00", location: "Library", type: "task" },
  
  // April 2026
  { id: 9, title: "Settlement Conference - Tech Inc.", date: new Date(2026, 3, 5), time: "09:00", endTime: "12:00", location: "Mediator's Office", type: "meeting" },
  { id: 10, title: "Submit Final Arguments", date: new Date(2026, 3, 15), time: "16:00", endTime: "17:00", location: "Online Portal", type: "deadline" },
  { id: 11, title: "Initial Consultation - David Lee", date: new Date(2026, 3, 20), time: "11:00", endTime: "12:00", location: "Office Conference Room", type: "meeting" },
  { id: 12, title: "Tax Compliance Review", date: new Date(2026, 3, 22), time: "13:00", endTime: "15:00", location: "Finance Dept", type: "task" },
  { id: 13, title: "Oral Argument - App. Court", date: new Date(2026, 3, 28), time: "10:00", endTime: "11:30", location: "State Appellate Court", type: "hearing" },
  
  // May 2026
  { id: 14, title: "Board Meeting Prep", date: new Date(2026, 4, 3), time: "14:00", endTime: "16:00", location: "Law Library", type: "task" },
  { id: 15, title: "Annual Partner Retreat", date: new Date(2026, 4, 10), time: "09:00", endTime: "17:00", location: "Grand Hotel", type: "meeting" },
  { id: 16, title: "Expert Witness Prep", date: new Date(2026, 4, 18), time: "10:30", endTime: "12:30", location: "Lawder & Sons Office", type: "task" },
  { id: 17, title: "Discovery Deadline - Case 98A", date: new Date(2026, 4, 25), time: "17:00", endTime: "17:00", location: "Court 33", type: "deadline" },
  { id: 18, title: "Sentencing Hearing", date: new Date(2026, 4, 29), time: "09:30", endTime: "11:00", location: "Federal Courthouse", type: "hearing" }
];

const emptyEvent = { title: "", date: "", time: "", endTime: "", location: "", type: "meeting" };

export default function CalendarPage() {
  const [view, setView] = useState("day");
  const [currentDate, setCurrentDate] = useState(new Date());
  const [events, setEvents] = useState(initialEvents);
  const [newEvent, setNewEvent] = useState(emptyEvent);
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [showEventDetails, setShowEventDetails] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [isClosingEventDetails, setIsClosingEventDetails] = useState(false);
  const [showDayEvents, setShowDayEvents] = useState(false);
  const [selectedDayDate, setSelectedDayDate] = useState(null);
  const [isClosingDayEvents, setIsClosingDayEvents] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      const dateParam = params.get("date");
      if (dateParam) {
        const [y, m, d] = dateParam.split("-").map(Number);
        if (y && m && d) {
          setCurrentDate(new Date(y, m - 1, d));
          setView("day");
        }
      }
    }
  }, []);

  const navigate = (dir) => {
    const d = currentDate;
    if (view === "day") setCurrentDate(new Date(d.getFullYear(), d.getMonth(), d.getDate() + dir));
    else if (view === "week") setCurrentDate(new Date(d.getFullYear(), d.getMonth(), d.getDate() + dir * 7));
    else setCurrentDate(new Date(d.getFullYear(), d.getMonth() + dir));
  };

  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.date || !newEvent.time) return;
    setEvents([...events, { id: Date.now(), ...newEvent, date: new Date(newEvent.date), endTime: newEvent.endTime || newEvent.time }]);
    setNewEvent(emptyEvent);
    setShowAddEvent(false);
  };

  const handleDeleteEvent = (id) => setEvents(events.filter(e => e.id !== id));

  const closeEventDetails = () => {
    setIsClosingEventDetails(true);
    setTimeout(() => { setShowEventDetails(false); setIsClosingEventDetails(false); setSelectedEvent(null); }, 300);
  };

  const closeDayEvents = () => {
    setIsClosingDayEvents(true);
    setTimeout(() => { setShowDayEvents(false); setIsClosingDayEvents(false); setSelectedDayDate(null); }, 300);
  };

  const openEventDetails = (event) => { setSelectedEvent(event); setShowEventDetails(true); };

  const eventsForDate = (date) => getEventsForDate(events, date);

  return (
    <div className="h-screen flex flex-col overflow-hidden px-3 py-4 sm:px-5 sm:py-6 lg:px-8 lg:py-8">
      <div className="flex-1 flex flex-col overflow-hidden">

        {/* Header - matches dashboard style */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 sm:gap-4 mb-4 sm:mb-6 shrink-0">
          <div className="shrink-0">
            <h1 className="text-[1.5rem] sm:text-[1.75rem] lg:text-[2rem] font-semibold tracking-[-0.02em] text-colordark mb-0.5 sm:mb-1.5 leading-tight">
              Calendar
            </h1>
            <p className="text-[0.8125rem] sm:text-[0.9375rem] text-colordark/50 font-bold hidden sm:block">{getHeaderText(view, currentDate)}</p>
          </div>
          <CalendarHeader
            view={view}
            currentDate={currentDate}
            headerText={getHeaderText(view, currentDate)}
            onViewChange={setView}
            onPrev={() => navigate(-1)}
            onNext={() => navigate(1)}
            onToday={() => setCurrentDate(new Date())}
            onDateSelect={setCurrentDate}
            onCreateEvent={() => setShowAddEvent(true)}
          />
        </div>

        <div className="flex-1 overflow-hidden">
          {view === "day" && (
            <DayView
              currentDate={currentDate}
              dayEvents={eventsForDate(currentDate)}
              onEventClick={openEventDetails}
              onDeleteEvent={handleDeleteEvent}
            />
          )}
          {view === "week" && (
            <WeekView
              weekDays={getWeekDays(currentDate)}
              getEventsForDate={eventsForDate}
              onEventClick={openEventDetails}
            />
          )}
          {view === "month" && (
            <MonthView
              currentDate={currentDate}
              getEventsForDate={eventsForDate}
              onDayClick={(date) => { setSelectedDayDate(date); setShowDayEvents(true); }}
            />
          )}
        </div>
      </div>

      {showEventDetails && selectedEvent && (
        <EventDetailsPanel
          event={selectedEvent}
          isClosing={isClosingEventDetails}
          onClose={closeEventDetails}
          onDelete={() => { handleDeleteEvent(selectedEvent.id); closeEventDetails(); }}
        />
      )}

      {showDayEvents && selectedDayDate && (
        <DayEventsPanel
          date={selectedDayDate}
          events={eventsForDate(selectedDayDate)}
          isClosing={isClosingDayEvents}
          onClose={closeDayEvents}
          onEventClick={(event) => { setSelectedEvent(event); closeDayEvents(); setTimeout(() => setShowEventDetails(true), 300); }}
          onDeleteEvent={handleDeleteEvent}
          onAddEvent={() => { closeDayEvents(); setTimeout(() => setShowAddEvent(true), 300); }}
        />
      )}

      {showAddEvent && (
        <AddEventModal
          newEvent={newEvent}
          onChange={setNewEvent}
          onAdd={handleAddEvent}
          onClose={() => setShowAddEvent(false)}
        />
      )}
    </div>
  );
}
