"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";

export default function ProfilePage() {
  const [user, setUser] = useState(null);
  const [displayName, setDisplayName] = useState("");
  const [saving, setSaving] = useState(false);
  const [nameMsg, setNameMsg] = useState({ type: "", text: "" });

  useEffect(() => {
    const getUser = async () => {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUser(user);
        setDisplayName(
          user.user_metadata?.full_name ||
          user.user_metadata?.first_name ||
          user.email?.split("@")[0] || ""
        );
      }
    };
    getUser();
  }, []);

  const handleSaveName = async () => {
    setSaving(true);
    const supabase = createClient();
    const { error } = await supabase.auth.updateUser({ data: { full_name: displayName } });
    setSaving(false);
    setNameMsg(error ? { type: "error", text: "Failed to update." } : { type: "success", text: "Saved." });
    setTimeout(() => setNameMsg({ type: "", text: "" }), 3000);
  };

  const initials = user?.email?.charAt(0).toUpperCase() || "U";
  const memberSince = user?.created_at
    ? new Date(user.created_at).toLocaleDateString("en-US", { month: "long", year: "numeric" })
    : null;

  return (
    <div className="min-h-screen">
      <div className="px-6 md:px-10 py-8 md:py-10 max-w-xl">

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-[1.75rem] lg:text-[2rem] font-semibold tracking-[-0.02em] text-colordark mb-1.5 leading-tight">Profile</h1>
          <p className="text-[0.9375rem] text-colordark/50">Manage your account information</p>
        </div>

        {/* Avatar + Identity */}
        <div className="flex items-center gap-4 p-5 rounded-2xl border border-colordark/[0.06] mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-from to-blue-to flex items-center justify-center shrink-0 shadow-md shadow-blue-from/20">
            <span className="text-[1.25rem] font-bold text-white">{initials}</span>
          </div>
          <div>
            <p className="text-[1rem] font-semibold text-colordark tracking-[-0.01em]">{displayName || user?.email}</p>
            <p className="text-[0.8125rem] text-colordark/50 mt-0.5">{user?.email}</p>
            {memberSince && <p className="text-[0.75rem] text-colordark/40 mt-0.5">Member since {memberSince}</p>}
          </div>
        </div>

        {/* Fields */}
        <div className="space-y-6">

          {/* Display Name */}
          <div className="p-5 rounded-2xl border border-colordark/[0.06]">
            <label className="block text-[0.8125rem] font-semibold text-colordark/60 mb-3">Display Name</label>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Your name"
                className="flex-1 h-10 px-4 border border-colordark/[0.08] rounded-xl text-[0.875rem] text-colordark placeholder:text-colordark/35 focus:outline-none focus:border-blue-from/40 focus:shadow-[0_0_0_3px_rgba(59,130,246,0.08)] transition-all"
              />
              <button
                onClick={handleSaveName}
                disabled={saving}
                className="h-10 px-5 text-[0.875rem] font-semibold text-white bg-gradient-to-r from-blue-from to-blue-to hover:shadow-[0_4px_15px_-3px_rgba(59,130,246,0.4)] rounded-xl transition-all cursor-pointer disabled:opacity-50 shrink-0 shadow-sm"
              >
                {saving ? "Saving..." : "Save"}
              </button>
            </div>
            {nameMsg.text && (
              <p className={`text-[0.8125rem] mt-2 ${nameMsg.type === "error" ? "text-red-500" : "text-green-600"}`}>{nameMsg.text}</p>
            )}
          </div>

          {/* Email */}
          <div className="p-5 rounded-2xl border border-colordark/[0.06]">
            <label className="block text-[0.8125rem] font-semibold text-colordark/60 mb-3">Email Address</label>
            <div className="h-10 px-4 border border-colordark/[0.08] rounded-xl text-[0.875rem] text-colordark/55 flex items-center">
              {user?.email}
            </div>
            <p className="text-[0.75rem] text-colordark/40 mt-2">Email cannot be changed.</p>
          </div>

        </div>
      </div>
    </div>
  );
}
