"use client";

import { useState } from "react";
import UploadPanel from "@/app/components/translation/UploadPanel";
import TranslationPanel from "@/app/components/translation/TranslationPanel";

export default function TranslationPage() {
  const [uploadedFile, setUploadedFile] = useState(null);
  const [translatedContent, setTranslatedContent] = useState(null);
  const [targetLanguage, setTargetLanguage] = useState("Hindi");
  const [isTranslating, setIsTranslating] = useState(false);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();

    if (file.type === "text/plain") {
      reader.onload = (ev) => setUploadedFile({ name: file.name, size: (file.size / 1024).toFixed(2) + " KB", type: file.type, content: ev.target.result, file });
      reader.readAsText(file);
    } else if (file.type === "application/pdf") {
      reader.onload = (ev) => setUploadedFile({ name: file.name, size: (file.size / 1024).toFixed(2) + " KB", type: file.type, content: ev.target.result, file });
      reader.readAsDataURL(file);
    } else {
      setUploadedFile({ name: file.name, size: (file.size / 1024).toFixed(2) + " KB", type: file.type, content: null, file });
    }
  };

  const handleTranslate = () => {
    setIsTranslating(true);
    setTimeout(() => {
      setTranslatedContent({
        text: `Translation feature is currently under development.\n\nYour document has been processed and is ready for translation.\n\nDocument: ${uploadedFile.name}\nFrom: Auto-detected\nTo: ${targetLanguage}\n\nThank you for your patience.`,
        type: uploadedFile.type,
      });
      setIsTranslating(false);
    }, 2000);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <div className="flex-1 overflow-hidden flex flex-col md:flex-row border-t border-colordark/[0.06]">
        <UploadPanel uploadedFile={uploadedFile} onUpload={handleFileUpload} onClear={() => { setUploadedFile(null); setTranslatedContent(null); }} />
        <TranslationPanel uploadedFile={uploadedFile} isTranslating={isTranslating} translatedContent={translatedContent} targetLanguage={targetLanguage} onTargetChange={setTargetLanguage} onTranslate={handleTranslate} />
      </div>
    </div>
  );
}
