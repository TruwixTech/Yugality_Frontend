"use client";

import { useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { Search, Download, AlignLeft, Table, ChevronLeft } from "lucide-react";
import DocumentsPanel from "@/app/components/briefcase/DocumentsPanel";
import QueryView from "@/app/components/briefcase/QueryView";
import TableView from "@/app/components/briefcase/TableView";

const projectsData = {
  "companies-act-rules": {
    name: "Companies Act and Rules [updated till 27.07.2025]",
    files: [
      { id: 1, name: "Companies Act 2013 - Full Text.pdf", size: "8.4 MB", type: "pdf" },
      { id: 2, name: "Companies Amendment Rules 2024.pdf", size: "2.1 MB", type: "pdf" },
      { id: 3, name: "MCA Circulars 2025.pdf", size: "1.8 MB", type: "pdf" },
      { id: 4, name: "Schedule III - Balance Sheet Format.docx", size: "456 KB", type: "docx" },
      { id: 5, name: "NCLT Rules 2016.pdf", size: "3.2 MB", type: "pdf" },
    ],
    queries: [
      { id: 1, question: "What are the key provisions related to director responsibilities under the Companies Act 2013?", answer: "The Companies Act 2013 places significant responsibilities on directors including fiduciary duties, duty of care, and disclosure obligations. Directors must act in good faith, exercise independent judgment, and avoid conflicts of interest. Section 166 outlines these duties comprehensively.", tag: "Created By You" },
      { id: 2, question: "What are the penalties for non-compliance with filing requirements?", answer: "Non-compliance with filing requirements under the Companies Act attracts penalties ranging from monetary fines to imprisonment. Section 137 specifies that failure to file financial statements can result in fines up to Rs. 1,000 per day of default.", tag: "Created By You" },
      { id: 3, question: "How are related party transactions regulated under the Act?", answer: "Related party transactions are governed by Section 188 of the Companies Act 2013. All such transactions require prior approval of the Board of Directors, and in certain cases, shareholder approval through ordinary or special resolution.", tag: "Created By You" },
    ],
  },
  "facility-agreements-clean": {
    name: "Facility Agreements (Clean)",
    files: [
      { id: 1, name: "Term Loan Agreement - Draft v3.docx", size: "1.2 MB", type: "docx" },
      { id: 2, name: "Working Capital Facility Agreement.pdf", size: "3.5 MB", type: "pdf" },
      { id: 3, name: "Security Documents - Mortgage Deed.pdf", size: "2.8 MB", type: "pdf" },
      { id: 4, name: "Guarantee Agreement.docx", size: "890 KB", type: "docx" },
    ],
    queries: [
      { id: 1, question: "What are the key covenants in the facility agreement?", answer: "The facility agreement contains both financial and non-financial covenants. Financial covenants include maintaining a debt-to-equity ratio, minimum DSCR, and current ratio thresholds.", tag: "Created By You" },
      { id: 2, question: "What events constitute a default under the agreement?", answer: "Events of default include failure to pay any amount when due, breach of representations or covenants, insolvency proceedings, material adverse change, and cross-default provisions.", tag: "Created By You" },
    ],
  },
  "sha": {
    name: "SHA",
    files: [
      { id: 1, name: "Shareholders Agreement - Final.pdf", size: "5.6 MB", type: "pdf" },
      { id: 2, name: "SHA Amendment No. 1.docx", size: "340 KB", type: "docx" },
      { id: 3, name: "Board Resolutions.pdf", size: "1.1 MB", type: "pdf" },
    ],
    queries: [
      { id: 1, question: "What are the drag-along and tag-along rights under the SHA?", answer: "The SHA provides drag-along rights to majority shareholders holding more than 51% of shares, allowing them to compel minority shareholders to join in a sale. Tag-along rights protect minority shareholders by allowing them to participate in any sale on the same terms.", tag: "Created By You" },
    ],
  },
  "real-estate-lease-deed": {
    name: "REAL ESTATE- Lease Deed",
    files: [
      { id: 1, name: "Lease Deed - Commercial Property.pdf", size: "4.2 MB", type: "pdf" },
      { id: 2, name: "Property Title Documents.pdf", size: "6.8 MB", type: "pdf" },
      { id: 3, name: "NOC from Society.pdf", size: "780 KB", type: "pdf" },
      { id: 4, name: "Rent Agreement Draft.docx", size: "520 KB", type: "docx" },
      { id: 5, name: "Floor Plan.pdf", size: "2.3 MB", type: "pdf" },
      { id: 6, name: "Encumbrance Certificate.pdf", size: "1.4 MB", type: "pdf" },
    ],
    queries: [
      { id: 1, question: "What are the termination clauses in the lease deed?", answer: "The lease deed provides for termination by either party with 3 months written notice. The lessor may terminate immediately in case of non-payment of rent for more than 2 consecutive months.", tag: "Created By You" },
      { id: 2, question: "What are the maintenance obligations of the lessee?", answer: "The lessee is responsible for day-to-day maintenance and minor repairs. Major structural repairs remain the responsibility of the lessor.", tag: "Created By You" },
    ],
  },
  "sec-orders-2020-2025": {
    name: "SEC ORDERS (2020 - 2025)",
    files: [
      { id: 1, name: "SEC Order - Jan 2020.pdf", size: "2.1 MB", type: "pdf" },
      { id: 2, name: "SEC Order - Mar 2021.pdf", size: "1.8 MB", type: "pdf" },
      { id: 3, name: "SEC Order - Nov 2022.pdf", size: "3.4 MB", type: "pdf" },
      { id: 4, name: "SEC Order - Jul 2023.pdf", size: "2.7 MB", type: "pdf" },
      { id: 5, name: "SEC Order - Feb 2024.pdf", size: "1.9 MB", type: "pdf" },
      { id: 6, name: "SEC Order - Sep 2025.pdf", size: "2.2 MB", type: "pdf" },
    ],
    queries: [
      { id: 1, question: "What enforcement actions were taken by SEC between 2020-2025?", answer: "The SEC orders reflect a range of enforcement actions including penalties for insider trading, market manipulation, and disclosure violations. The orders show an increasing trend in penalties.", tag: "Created By You" },
      { id: 2, question: "What are the common violations cited across these orders?", answer: "Common violations include failure to disclose material information, misrepresentation in financial statements, unauthorized trading activities, and non-compliance with reporting requirements.", tag: "Created By You" },
      { id: 3, question: "How have penalty amounts changed over the years?", answer: "Analysis of the SEC orders shows a significant increase in penalty amounts from 2020 to 2025. Average penalties have increased by approximately 40% over this period.", tag: "Created By You" },
    ],
  },
};

export default function BriefcaseProjectPage() {
  const router = useRouter();
  const { projectId } = useParams();

  const project = projectsData[projectId] || { name: projectId, files: [], queries: [] };
  const [files, setFiles] = useState(project.files);
  const [activeTab, setActiveTab] = useState("query");
  const [fileSearch, setFileSearch] = useState("");
  const [resultSearch, setResultSearch] = useState("");

  return (
    <div className="min-h-screen px-4 sm:px-6 md:px-10 py-6 sm:py-8 md:py-10">
      {/* Header */}
      <div className="mb-5 sm:mb-6 flex flex-col gap-4 sm:gap-6">
        <div className="flex items-start gap-3 sm:gap-4">
          <button onClick={() => router.push("/dashboard/briefcase")} className="w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center rounded-xl border border-colordark/[0.08] text-colordark/50 hover:text-blue-from hover:border-blue-from/40 transition-all shrink-0 cursor-pointer shadow-sm mt-0.5">
            <ChevronLeft size={18} strokeWidth={2} />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="text-[1.125rem] sm:text-[1.375rem] md:text-[1.75rem] font-semibold text-colordark tracking-[-0.02em] leading-tight break-words">
              {project.name}
            </h1>
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[0.8125rem] sm:text-[0.875rem] text-colordark/45 mt-1 overflow-hidden">
              <span className="cursor-pointer hover:text-blue-from transition-colors whitespace-nowrap" onClick={() => router.push("/dashboard/briefcase")}>Briefcase</span>
              <span>/</span>
              <span className="truncate">{project.name}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Layout — stacks on mobile, side-by-side on lg */}
      <div className="flex flex-col lg:grid lg:grid-cols-[1fr_340px] gap-5 sm:gap-6">
        
        {/* Left Content Area */}
        <div className="flex flex-col gap-5 sm:gap-6 min-w-0">
          <div className="rounded-2xl border border-colordark/[0.06]">
            
            {/* Toolbar */}
            <div className="px-4 sm:px-6 py-3 sm:py-4 flex flex-col gap-3 sm:flex-row sm:items-center justify-between border-b border-colordark/[0.06]">
              {/* Tab switcher */}
              <div className="flex items-center bg-colordark/[0.03] p-1 rounded-xl self-start">
                <button onClick={() => setActiveTab("query")}
                  className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 text-[0.8125rem] sm:text-[0.875rem] font-medium rounded-lg transition-all cursor-pointer ${activeTab === "query" ? "bg-white text-blue-from shadow-sm border border-colordark/[0.04]" : "text-colordark/55 hover:text-colordark"}`}>
                  <AlignLeft size={15} strokeWidth={2} />
                  <span className="hidden xs:inline">Query</span> View
                </button>
                <button onClick={() => setActiveTab("table")}
                  className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 text-[0.8125rem] sm:text-[0.875rem] font-medium rounded-lg transition-all cursor-pointer ${activeTab === "table" ? "bg-white text-blue-from shadow-sm border border-colordark/[0.04]" : "text-colordark/55 hover:text-colordark"}`}>
                  <Table size={15} strokeWidth={2} />
                  <span className="hidden xs:inline">Table</span> View
                </button>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 sm:gap-3">
                <button className="flex items-center gap-1.5 px-3 sm:px-4 h-9 text-[0.8125rem] font-medium text-colordark/60 hover:text-colordark border border-colordark/[0.08] hover:border-colordark/15 rounded-xl transition-all cursor-pointer shadow-sm">
                  <Download size={14} strokeWidth={2} />
                  <span className="hidden sm:inline">Results</span>
                </button>
                <div className="relative group flex-1 sm:flex-none">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-colordark/30 group-focus-within:text-blue-from transition-colors" strokeWidth={2} />
                  <input type="text" placeholder="Search Results" value={resultSearch} onChange={(e) => setResultSearch(e.target.value)}
                    className="w-full sm:w-[200px] h-9 pl-9 pr-3 text-[0.8125rem] text-colordark placeholder:text-colordark/35 border border-colordark/[0.08] rounded-xl focus:outline-none focus:border-blue-from/40 focus:shadow-[0_0_0_3px_rgba(59,130,246,0.06)] transition-all cursor-text shadow-sm" />
                </div>
              </div>
            </div>

            {/* Content Display */}
            <div className="overflow-x-auto">
              <div className="p-4 sm:p-6 min-w-0">
              {activeTab === "query"
                ? <QueryView queries={project.queries} />
                : <TableView queries={project.queries} />
              }
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar — DocumentsPanel */}
        <div className="flex flex-col">
          <DocumentsPanel
            files={files}
            setFiles={setFiles}
            fileSearch={fileSearch}
            setFileSearch={setFileSearch}
          />
        </div>

      </div>
    </div>
  );
}
