"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Briefcase } from "lucide-react";
import BriefcaseHeader from "@/app/components/briefcase/BriefcaseHeader";
import ProjectsTable from "@/app/components/briefcase/ProjectsTable";
import CreateProjectModal from "@/app/components/briefcase/CreateProjectModal";
import UploadModal from "@/app/components/briefcase/UploadModal";

const initialCases = [
    {
        id: "companies-act-rules",
        name: "Companies Act and Rules ",
        fileCount: 5,
        lastModified: "27 Jul 2025",
        lastUpdated: "27 Jul 2025",
        owner: "You",
        starred: false,
    },
    {
        id: "facility-agreements-clean",
        name: "Facility Agreements (Clean)",
        fileCount: 4,
        lastModified: "15 Mar 2025",
        lastUpdated: "15 Mar 2025",
        owner: "You",
        starred: false,
    },
    {
        id: "sha",
        name: "SHA",
        fileCount: 3,
        lastModified: "10 Feb 2025",
        lastUpdated: "10 Feb 2025",
        owner: "You",
        starred: false,
    },
    {
        id: "real-estate-lease-deed",
        name: "REAL ESTATE- Lease Deed",
        fileCount: 6,
        lastModified: "5 Jan 2025",
        lastUpdated: "5 Jan 2025",
        owner: "You",
        starred: false,
    },
    {
        id: "sec-orders-2020-2025",
        name: "SEC ORDERS (2020 - 2025)",
        fileCount: 6,
        lastModified: "20 Dec 2024",
        lastUpdated: "20 Dec 2024",
        owner: "You",
        starred: false,
    },
];

export default function BriefcasePage() {
    const router = useRouter();
    const [cases, setCases] = useState(initialCases);
    const [search, setSearch] = useState("");

    const [showCreateModal, setShowCreateModal] = useState(false);
    const [showUploadModal, setShowUploadModal] = useState(false);

    // Create project modal state
    const [projectName, setProjectName] = useState("");
    const [uploadedDocs, setUploadedDocs] = useState([]);

    // Upload modal state
    const [selectedCase, setSelectedCase] = useState("");
    const [selectedFile, setSelectedFile] = useState(null);

    const filtered = cases.filter((c) =>
        c.name.toLowerCase().includes(search.toLowerCase())
    );

    const handleRowClick = (id) => {
        router.push(`/dashboard/briefcase/${id}`);
    };

    const handleStar = (e, id) => {
        e.stopPropagation();
        setCases(cases.map((c) => (c.id === id ? { ...c, starred: !c.starred } : c)));
    };

    const handleDelete = (e, id) => {
        if (e) e.stopPropagation();
        if (confirm("Delete this case and all its files?")) {
            setCases(cases.filter((c) => c.id !== id));
        }
    };

    const handleCreateProject = () => {
        if (!projectName.trim()) return;
        const newId = projectName.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
        const newCase = {
            id: newId,
            name: projectName,
            fileCount: uploadedDocs.length,
            lastModified: new Date().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }),
            lastUpdated: new Date().toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }),
            owner: "You",
            starred: false,
        };
        setCases([newCase, ...cases]);
        setProjectName("");
        setUploadedDocs([]);
        setShowCreateModal(false);
    };

    const handleUpload = () => {
        if (!selectedFile || !selectedCase) return;
        setCases(
            cases.map((c) =>
                c.id === selectedCase ? { ...c, fileCount: c.fileCount + 1 } : c
            )
        );
        setSelectedFile(null);
        setSelectedCase("");
        setShowUploadModal(false);
    };

    return (
        <div className="min-h-screen px-4 sm:px-6 md:px-10 py-6 sm:py-8 md:py-10">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 sm:gap-6 mb-6 sm:mb-8">
                <div>
                    <h1 className="text-[1.25rem] sm:text-[1.5rem] font-semibold text-colordark tracking-[-0.02em]">
                        Briefcase
                    </h1>
                    <p className="text-[0.8125rem] sm:text-[0.875rem] text-colordark/50 font-bold mt-1">
                        {cases.length} projects · Manage your legal documents and cases
                    </p>
                </div>
                <BriefcaseHeader
                    currentFolder={null}
                    onUpload={() => setShowUploadModal(true)}
                    onNewCase={() => setShowCreateModal(true)}
                />
            </div>

            {/* Search */}
            <div className="mb-5 sm:mb-6">
                <div className="relative group max-w-full sm:max-w-sm">
                    <Search
                        size={14}
                        className="absolute left-3.5 top-1/2 -translate-y-1/2 text-colordark/30 group-focus-within:text-blue-from transition-colors"
                        strokeWidth={2}
                    />
                    <input
                        type="text"
                        placeholder="Search projects..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="w-full h-10 pl-10 pr-4 text-[0.8125rem] text-colordark placeholder:text-colordark/35 border border-colordark/[0.08] rounded-xl focus:outline-none focus:border-blue-from/40 focus:shadow-[0_0_0_3px_rgba(59,130,246,0.08)] transition-all shadow-sm"
                    />
                </div>
            </div>

            {/* Content */}
            {filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 sm:py-20 text-center">
                    <Briefcase size={48} className="text-colordark/15 mb-4" strokeWidth={1.5} />
                    <p className="text-[1rem] font-medium text-colordark/50 mb-1">No projects found</p>
                    <p className="text-[0.875rem] text-colordark/35">
                        {search ? "Try a different search term" : "Create your first project to get started"}
                    </p>
                </div>
            ) : (
                <ProjectsTable
                    projects={cases}
                    filtered={filtered}
                    onRowClick={handleRowClick}
                    onStar={handleStar}
                    onDelete={handleDelete}
                />
            )}

            {/* Create Project Modal */}
            {showCreateModal && (
                <CreateProjectModal
                    projectName={projectName}
                    setProjectName={setProjectName}
                    uploadedDocs={uploadedDocs}
                    setUploadedDocs={setUploadedDocs}
                    onCreate={handleCreateProject}
                    onClose={() => {
                        setShowCreateModal(false);
                        setProjectName("");
                        setUploadedDocs([]);
                    }}
                />
            )}

            {/* Upload Modal */}
            {showUploadModal && (
                <UploadModal
                    cases={cases}
                    currentFolder={null}
                    selectedCase={selectedCase}
                    onCaseChange={setSelectedCase}
                    selectedFile={selectedFile}
                    onFileSelect={(e) => setSelectedFile(e.target.files[0])}
                    onUpload={handleUpload}
                    onClose={() => {
                        setShowUploadModal(false);
                        setSelectedFile(null);
                        setSelectedCase("");
                    }}
                />
            )}
        </div>
    );
}
