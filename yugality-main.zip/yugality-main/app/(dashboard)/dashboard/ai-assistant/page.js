"use client";

import { useState } from "react";
import { Menu } from "lucide-react";
import ChatSidebar from "@/app/components/ai-assistant/ChatSidebar";
import ChatWelcome from "@/app/components/ai-assistant/ChatWelcome";
import ChatMessages from "@/app/components/ai-assistant/ChatMessages";
import ChatInput from "@/app/components/ai-assistant/ChatInput";
import generateFullDraft from "@/app/components/ai-assistant/templates/draftGenerator";

const dummyResponses = {
  Ask: [
    "Based on my analysis of the relevant case law, I can provide the following legal insights...\n\nThe precedent established in Smith v. Johnson (2020) suggests that courts have consistently held that contractual obligations must be interpreted in light of the parties' original intent. This principle would likely apply to your situation.\n\nWould you like me to elaborate on any specific aspect of this analysis?",
    "That's an excellent legal question. Here's a comprehensive overview:\n\n1. **Applicable Law**: The relevant statutes in this jurisdiction include...\n2. **Key Precedents**: Several landmark cases have shaped this area of law...\n3. **Practical Implications**: For your specific situation, I would recommend...\n\nShall I draft a formal legal memo summarizing these points?",
    "Great question! Here's what the law says about this:\n\nUnder current statutory interpretation, the burden of proof typically falls on the party asserting the claim. The standard of evidence required varies depending on whether this is a civil or criminal matter.\n\nIs there a specific jurisdiction you'd like me to focus on for a more detailed analysis?"
  ],
  Research: [
    "I've completed a comprehensive sweep of relevant jurisprudence. Here are my findings across key jurisdictions:\n\n1. Most courts have interpreted this type of clause narrowly.\n2. Recent statutory amendments (effective 2023) have placed a stricter burden of proof.\n\nI recommend reviewing the leading case of Davis v. Miller for further context.",
    "My research indicates a split in authority regarding this matter. While the 2nd Circuit has adopted a more permissive approach, the 9th Circuit requires clear and unambiguous language to enforce such provisions.\n\nWould you like me to pull the full text of these diverging opinions?"
  ],
  Draft: [
    // These will be overridden dynamically by generateFullDraft in handleSend
    "DEFAULT_DRAFT",
    "DEFAULT_DRAFT"
  ],
  Summarize: [
    "**Case Law Summary**\n\n**Case:** *Smith v. Continental LLC* (2024)\n**Court:** Supreme Court of India\n**Citation:** 2024 SCC 1456\n\n---\n\n**Facts**\nThe petitioner filed a suit alleging breach of a non-compete agreement after the respondent started a competing business within the restricted territory and time period.\n\n**Issues**\n1. Whether the non-compete clause was enforceable under Section 27 of the Indian Contract Act.\n2. Whether the restriction was reasonable in scope and duration.\n\n**Held**\nThe court ruled **in favor of the petitioner**, holding that the non-compete clause was reasonable and enforceable as it was limited to 2 years and a specific geographic area.\n\n**Key Ratio**\n- Post-employment non-compete clauses are generally void under Section 27, **unless** they form part of a goodwill sale or are narrowly tailored.\n- The court applied a **reasonableness test** balancing employer interests and employee rights.\n\n**Precedents Cited**\n- *Niranjan Shankar Golikari v. Century Spinning Co.* (1967)\n- *Superintendence Company of India v. Krishan Murgai* (1981)\n\nWould you like me to summarize another case or compare this with related judgments?",
    "**Case Law Summary**\n\n**Case:** *In Re: Baker Trust Dissolution* (2023)\n**Court:** Delhi High Court\n**Citation:** 2023 DHC 892\n\n---\n\n**Facts**\nBeneficiaries of the Baker Family Trust challenged the trustee's decision to dissolve the trust and distribute assets disproportionately, alleging breach of fiduciary duty.\n\n**Issues**\n1. Whether the trustee exceeded their powers under the trust deed.\n2. Whether equitable relief could be granted to the aggrieved beneficiaries.\n\n**Held**\nThe court held that the trustee had **acted ultra vires** by failing to comply with the distribution clause in the trust deed. A new trustee was appointed.\n\n**Key Ratio**\n- Trustees must act strictly within the scope of the trust instrument.\n- Courts retain inherent jurisdiction to remove trustees acting in breach of fiduciary obligations.\n\n**Precedents Cited**\n- *Kamal Kant v. District Judge* (1991)\n- *Indian Oil Corporation v. Union of India* (2004)\n\nShall I provide a deeper analysis of the fiduciary duty standards applied here?"
  ],
  Predict: [
    "**Judgment Outcome Prediction**\n\n**Case Under Analysis:** Contract Dispute — Non-Payment of Services\n\n**Predicted Outcome**\n🟢 **High probability of success for the Plaintiff** (78% confidence)\n\n**Analysis Factors**\n\n• **Contractual Evidence** — Strong — signed agreement with clear terms (High)\n• **Performance Proof** — Invoices + delivery receipts available (High)\n• **Defendant's Defense** — Weak — no written objection raised (Medium)\n• **Jurisdictional Precedent** — Favorable — 7 of 9 similar cases ruled for plaintiff (High)\n• **Limitation Period** — Within time — filed 8 months after breach (Low)\n\n**Similar Past Outcomes**\n\n1. **Apex Corp v. Stellar Solutions** (2023) — **Plaintiff won** — Damages of ₹45L awarded\n2. **Gupta Enterprises v. RK Traders** (2022) — **Plaintiff won** — Specific performance ordered\n3. **Mehta Industries v. Global Infra** (2023) — **Settled** — 85% of claimed amount\n\n**Recommended Strategy**\n\n• File for **summary judgment** given the strength of documentary evidence.\n• Prepare alternative argument for **quantum meruit** if contract terms are disputed.\n• Consider **mediation** to expedite resolution.\n\n⚠️ This prediction is based on pattern analysis and should not be treated as legal advice. Always consult with your legal team before making strategic decisions.\n\nWould you like me to analyze specific risk factors or generate a detailed case strategy?",
    "**Judgment Outcome Prediction**\n\n**Case Under Analysis:** Employment Termination Dispute\n\n**Predicted Outcome**\n🟡 **Moderate probability of success for the Employee** (54% confidence)\n\n**Analysis Factors**\n\n• **Termination Notice** — Irregular — 7 days instead of required 30 (High)\n• **Cause Documentation** — Mixed — verbal warnings but no written PIP (Medium)\n• **Employment Contract** — Standard — at-will with notice clause (Medium)\n• **Company Policy Compliance** — Partial — HR process not fully followed (High)\n• **Witness Availability** — Limited — 2 of 4 colleagues willing to testify (Low)\n\n**Similar Past Outcomes**\n\n1. **Sharma v. TechVista Pvt Ltd** (2024) — **Employee won** — Reinstatement ordered\n2. **Kapoor v. FinServ Global** (2023) — **Employer won** — Termination upheld\n3. **Reddy v. MegaCorp Industries** (2023) — **Settled** — 6 months' compensation\n\n**Recommended Strategy**\n\n• Focus on the **procedural irregularity** of the notice period.\n• Gather **documentary evidence** of the incomplete PIP process.\n• Consider filing under **Industrial Disputes Act** if applicable.\n\n⚠️ This prediction is based on pattern analysis and should not be treated as legal advice. Always consult with your legal team before making strategic decisions.\n\nWould you like me to assess the damages calculation or review applicable labor laws?"
  ]
};

let responseIndex = 0;

export default function AIAssistantPage() {
  const [message, setMessage] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [mode, setMode] = useState("Ask");
  const hasMessages = messages.length > 0;

  const handleSend = (attachedItems = []) => {
    if (!message.trim() && attachedItems.length === 0) return;

    let displayMessage = message;
    if (attachedItems.length > 0) {
      const names = attachedItems.map(i => i.name).join(", ");
      displayMessage = message ? `${message}\n\n[Attached: ${names}]` : `[Attached: ${names}]`;
    }

    const userMsg = { id: Date.now(), type: "user", content: displayMessage, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setMessage("");
    setIsTyping(true);

    setTimeout(() => {
      let response = "";
      let isDraftResponse = mode === "Draft";
      const templatesAttached = attachedItems.filter(item => item.id.startsWith("template-"));

      if (mode === "Draft") {
        if (templatesAttached.length > 0) {
          const templateName = templatesAttached[0].name.replace(" Template", "");
          response = generateFullDraft(templateName);
        } else {
          const defaultNames = ["NON-DISCLOSURE AGREEMENT", "GENERAL SERVICE AGREEMENT"];
          const selectedName = defaultNames[responseIndex % defaultNames.length];
          response = generateFullDraft(selectedName);
          responseIndex++;
        }
      } else {
        const responsesForMode = dummyResponses[mode] || dummyResponses.Ask;
        response = responsesForMode[responseIndex % responsesForMode.length];
        responseIndex++;
      }

      const assistantMsg = { id: Date.now() + 1, type: "assistant", content: response, timestamp: new Date(), isDraft: isDraftResponse };
      setMessages(prev => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <div className="flex h-screen relative">
      {sidebarOpen && (
        <div className="fixed inset-0 bg-colordark/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      <ChatSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 flex flex-col overflow-hidden bg-colorlight">
        {/* Mobile sidebar toggle for assistant specific view */}
        <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 text-colordark/60 hover:text-colordark bg-colorwhite hover:bg-colorlight rounded-lg transition-all cursor-pointer shadow-sm border border-colordark/6 m-4 w-fit">
          <Menu size={18} strokeWidth={2} />
        </button>

        {/* Chat area - welcome or messages */}
        {!hasMessages ? (
          <div className="flex-1 flex items-center justify-center px-4 py-8">
            <ChatWelcome onSuggestion={(text) => { setMessage(text); }} />
          </div>
        ) : (
          <ChatMessages messages={messages} isTyping={isTyping} />
        )}

        <ChatInput
          value={message}
          onChange={setMessage}
          onSend={handleSend}
          mode={mode}
          onModeChange={setMode}
        />
      </div>
    </div>
  );
}
