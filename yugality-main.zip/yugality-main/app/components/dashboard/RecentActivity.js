"use client";

import { Upload, Edit3, FilePlus, Share2, Download } from "lucide-react";

const activities = [
  { action: "Uploaded", item: "Evidence_A_Final.pdf", case: "Case #2341", time: "12 min ago", icon: Upload },
  { action: "Updated", item: "Case Chronology: Miller Estate", case: "Case #2298", time: "2 hours ago", icon: Edit3 },
  { action: "Shared", item: "brief_v2.docx with Sarah Chen", case: "Case #2156", time: "Yesterday", icon: Share2 },
  { action: "Created", item: "Discovery Response", case: "Case #2341", time: "2 days ago", icon: FilePlus },
  { action: "Downloaded", item: "Court Order: Injunction Relief", case: "Case #2298", time: "3 days ago", icon: Download },
];

export default function RecentActivity() {
  return (
    <div className="rounded-2xl border border-colordark/[0.06] h-full">
      {/* Header */}
      <div className="px-6 py-5 border-b border-colordark/[0.06]">
        <h2 className="text-[1rem] font-semibold text-colordark tracking-[-0.02em]">Recent Activity</h2>
      </div>

      {/* Items */}
      <div className="divide-y divide-colordark/[0.04]">
        {activities.map((activity, i) => {
          const Icon = activity.icon;
          return (
            <div key={i} className="flex items-start gap-3.5 px-6 py-4 cursor-pointer hover:bg-colordark/[0.015] transition-colors group">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-from/10 to-blue-to/10 flex items-center justify-center shrink-0 mt-0.5 group-hover:from-blue-from/15 group-hover:to-blue-to/15 transition-all">
                <Icon size={14} strokeWidth={1.8} className="text-blue-from/70 group-hover:text-blue-from transition-colors" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[0.875rem] text-colordark leading-snug mb-1.5">
                  <span className="font-bold">{activity.action}</span>{" "}
                  <span className="font-bold text-colordark/60">{activity.item}</span>
                </p>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[0.6875rem] font-bold text-colordark/45 uppercase tracking-wider">{activity.case}</span>
                  <span className="text-colordark/25">·</span>
                  <span className="text-[0.6875rem] text-colordark/45 font-bold">{activity.time}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
