"use client";

import { useState } from "react";
import { ArrowRight, Clock, Plus } from "lucide-react";
import AddDeadlineModal from "./AddDeadlineModal";

const initialDeadlines = [
  { title: "File Motion to Dismiss", case: "Case #2341", date: "Due in 4h", assignee: "You", urgent: "high" },
  { title: "Discovery Response Due", case: "Case #2298", date: "Today at 5 PM", assignee: "You", urgent: "medium" },
  { title: "Deposition Preparation", case: "Case #2156", date: "Tomorrow", assignee: "Team", urgent: "low" },
];

const urgencyConfig = {
  high:   { dot: "bg-red-500",     label: "Urgent",   labelClass: "text-red-600 bg-red-50" },
  medium: { dot: "bg-amber-400",   label: "Pending",  labelClass: "text-amber-600 bg-amber-50" },
  low:    { dot: "bg-colordark/20", label: "Upcoming", labelClass: "text-colordark/40 bg-colordark/[0.04]" },
};

export default function CriticalDeadlines() {
  const [deadlines, setDeadlines] = useState(initialDeadlines);
  const [showModal, setShowModal] = useState(false);

  const handleAdd = (task) => {
    setDeadlines((prev) => [
      ...prev,
      {
        title: task.title,
        case: task.case || "—",
        date: task.date || "No date",
        assignee: "You",
        urgent: task.priority || "medium",
      },
    ]);
  };

  return (
    <>
      <div className="rounded-2xl border border-colordark/[0.06]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-colordark/[0.06]">
          <div>
            <h2 className="text-[1rem] font-semibold text-colordark tracking-[-0.02em]">Critical Deadlines</h2>
            <p className="text-[0.75rem] font-bold text-colordark/50 mt-0.5">{deadlines.length} items need attention</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center gap-1.5 h-8 px-3.5 rounded-lg text-[0.8125rem] font-semibold text-white bg-gradient-to-r from-blue-from to-blue-to hover:shadow-[0_4px_12px_-2px_rgba(59,130,246,0.3)] transition-all cursor-pointer shadow-sm"
            >
              <Plus size={14} strokeWidth={2.5} />
              Add
            </button>
            <a href="/dashboard/calendar" className="hidden sm:flex items-center gap-1 h-8 px-3 rounded-lg text-[0.75rem] font-semibold text-transparent bg-clip-text bg-gradient-to-r from-blue-from to-blue-to hover:opacity-70 transition-all">
              View all <ArrowRight size={12} strokeWidth={2} className="text-blue-from" />
            </a>
          </div>
        </div>

        {/* Items */}
        <div className="divide-y divide-colordark/[0.04]">
          {deadlines.map((item, i) => {
            const cfg = urgencyConfig[item.urgent];
            return (
              <div
                key={i}
                className="flex items-center justify-between gap-4 px-6 py-4 hover:bg-colordark/[0.015] transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3.5 flex-1 min-w-0">
                  <span className={`w-2 h-2 rounded-full shrink-0 ${cfg.dot}`} />
                  <div className="min-w-0">
                    <h3 className="text-[0.875rem] font-semibold text-colordark leading-tight truncate">{item.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[0.75rem] font-bold text-colordark/55">{item.case}</span>
                      <span className="text-colordark/25">·</span>
                      <span className="flex items-center gap-1 text-[0.75rem] font-bold text-colordark/50">
                        <Clock size={11} strokeWidth={2.5} />
                        {item.date}
                      </span>
                    </div>
                  </div>
                </div>
                
                <span className={`text-[0.5625rem] font-bold uppercase tracking-[0.08em] px-2.5 py-1.5 rounded-md shrink-0 ${cfg.labelClass}`}>
                  {cfg.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <AddDeadlineModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onAdd={handleAdd}
      />
    </>
  );
}
