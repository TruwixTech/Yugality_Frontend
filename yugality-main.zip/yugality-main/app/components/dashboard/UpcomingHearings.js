"use client";

import { MapPin, Clock, ArrowRight } from "lucide-react";

const hearings = [
  { title: "Evidentiary Hearing", case: "Smith vs. Continental LLC", date: "JAN 18", time: "2:00 PM", location: "Room 4B" },
  { title: "Summary Judgment", case: "In Re: Baker Trust", date: "JAN 22", time: "9:30 AM", location: "Courtroom 12" },
  { title: "Trial Date", case: "Case #2156", date: "JAN 28", time: "9:00 AM", location: "Court Room 1A" },
];

export default function UpcomingHearings() {
  return (
    <div className="rounded-2xl border border-colordark/[0.06] flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-colordark/[0.06]">
        <h2 className="text-[1rem] font-semibold text-colordark tracking-[-0.01em]">Hearings</h2>
        <a href="/dashboard/calendar" className="flex items-center gap-1 text-[0.75rem] font-semibold text-transparent bg-clip-text bg-gradient-to-r from-blue-from to-blue-to hover:opacity-70 transition-all">
          All <ArrowRight size={12} strokeWidth={2} className="text-blue-from" />
        </a>
      </div>

      {/* Items */}
      <div className="divide-y divide-colordark/[0.04] flex-1">
        {hearings.map((hearing, i) => (
          <div key={i} className="flex items-start gap-4 px-5 py-4 cursor-pointer group hover:bg-colordark/[0.015] transition-colors">
            <div className="shrink-0 w-[44px] h-[44px] rounded-xl bg-gradient-to-br from-blue-from to-blue-to flex flex-col items-center justify-center shadow-sm shadow-blue-from/15">
              <span className="text-[0.4375rem] font-bold text-white/60 uppercase tracking-widest leading-none block mb-0.5">{hearing.date.split(" ")[0]}</span>
              <span className="text-[1rem] font-bold text-white leading-none block tracking-[-0.02em]">{hearing.date.split(" ")[1]}</span>
            </div>
            <div className="flex-1 min-w-0 pt-0.5">
              <h3 className="text-[0.875rem] font-semibold text-colordark leading-tight mb-1 truncate">{hearing.title}</h3>
              <p className="text-[0.8125rem] font-bold text-colordark/55 mb-1.5 truncate">{hearing.case}</p>
              <div className="flex items-center gap-2.5 text-[0.75rem] text-colordark/50 font-bold">
                <span className="flex items-center gap-1"><Clock size={11} strokeWidth={2.5} />{hearing.time}</span>
                <span className="flex items-center gap-1"><MapPin size={11} strokeWidth={2.5} />{hearing.location}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
