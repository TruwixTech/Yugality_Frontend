"use client";

import { useState } from "react";
import { CheckCircle2, Circle, Plus } from "lucide-react";
import AddTaskModal from "./AddTaskModal";

const initialTasks = [
  { id: 1, title: "Review contract amendments", completed: true },
  { id: 2, title: "Client meeting at 2:00 PM", completed: true },
  { id: 3, title: "Draft response to opposing counsel", completed: true },
  { id: 4, title: "Update case timeline", completed: false },
  { id: 5, title: "Prepare witness questions", completed: false },
  { id: 6, title: "File court documents", completed: false },
  { id: 7, title: "Research precedent cases", completed: false },
];

export default function TodaysTasks() {
  const [tasks, setTasks] = useState(initialTasks);
  const [showModal, setShowModal] = useState(false);

  const toggle = (id) => setTasks(prev =>
    prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t)
  );

  const doneCount = tasks.filter(t => t.completed).length;
  const percent = Math.round((doneCount / tasks.length) * 100);

  const handleAdd = (task) => {
    setTasks((prev) => [
      ...prev,
      { id: Date.now(), title: task.title, completed: false },
    ]);
  };

  return (
    <>
      <div className="rounded-2xl border border-colordark/[0.06] flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-colordark/[0.06]">
          <h2 className="text-[1rem] font-semibold text-colordark tracking-[-0.01em]">Today&apos;s Tasks</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowModal(true)}
              className="w-7 h-7 flex items-center justify-center rounded-lg text-colordark/25 hover:text-colordark hover:bg-colordark/[0.04] transition-all cursor-pointer"
            >
              <Plus size={16} strokeWidth={2.5} />
            </button>
            <span className="text-[0.75rem] font-bold text-colordark/25">{doneCount}/{tasks.length}</span>
          </div>
        </div>

        {/* Progress bar */}
        <div className="px-5 pt-4 pb-1">
          <div className="h-1.5 bg-colordark/[0.04] rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-from to-blue-to rounded-full transition-all duration-700 ease-out"
              style={{ width: `${percent}%` }}
            />
          </div>
        </div>

        {/* Task list */}
        <div className="flex-1 overflow-y-auto px-2 py-2">
          {tasks.map((task) => (
            <div
              key={task.id}
              onClick={() => toggle(task.id)}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer hover:bg-colordark/[0.02] transition-colors group"
            >
              {task.completed ? (
                <CheckCircle2 className="w-[17px] h-[17px] text-blue-from shrink-0 transition-all" strokeWidth={2} />
              ) : (
                <Circle className="w-[17px] h-[17px] text-colordark/15 group-hover:text-colordark/30 shrink-0 transition-colors" strokeWidth={2} />
              )}
              <span className={`text-[0.8125rem] font-bold leading-tight select-none transition-all ${
                task.completed ? "text-colordark/20 line-through decoration-1" : "text-colordark/65"
              }`}>
                {task.title}
              </span>
            </div>
          ))}
        </div>
      </div>

      <AddTaskModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onAdd={handleAdd}
        title="Add Task"
      />
    </>
  );
}
