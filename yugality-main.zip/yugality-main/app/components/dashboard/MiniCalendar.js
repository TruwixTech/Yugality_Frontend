"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight, ChevronDown, X, Clock, MapPin } from "lucide-react";

const dayLabels = ["S", "M", "T", "W", "T", "F", "S"];
const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

// Sample events data
const sampleEvents = {
  "12": [
    { id: 1, title: "Client Meeting - Smith Case", time: "10:00 AM", location: "Conference Room A", type: "meeting" },
    { id: 2, title: "Court Hearing", time: "2:30 PM", location: "District Court", type: "hearing" },
  ],
  "18": [
    { id: 3, title: "Document Review", time: "9:00 AM", location: "Office", type: "task" },
  ],
  "25": [
    { id: 4, title: "Deposition", time: "11:00 AM", location: "Law Firm Office", type: "deposition" },
    { id: 5, title: "Team Sync", time: "3:00 PM", location: "Virtual", type: "meeting" },
  ],
};

export default function MiniCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showMonthDropdown, setShowMonthDropdown] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [showEventsModal, setShowEventsModal] = useState(false);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const handlePrevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const handleNextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const setMonth = (mIndex) => {
    setCurrentDate(new Date(year, mIndex, 1));
    setShowMonthDropdown(false);
  };

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay();
  const daysInPrevMonth = new Date(year, month, 0).getDate();
  const highlighted = [12, 18, 25];

  const today = new Date();
  const isCurrentMonth = today.getMonth() === month && today.getFullYear() === year;

  const gridCells = [];
  for (let i = firstDayOfMonth - 1; i >= 0; i--) {
    gridCells.push({ type: "prev", day: daysInPrevMonth - i });
  }
  for (let i = 1; i <= daysInMonth; i++) {
    gridCells.push({ type: "current", day: i });
  }
  const remainingCells = 42 - gridCells.length;
  for (let i = 1; i <= remainingCells; i++) {
    gridCells.push({ type: "next", day: i });
  }

  const handleDateClick = (day) => {
    setSelectedDate(day);
    setShowEventsModal(true);
  };

  const selectedDateEvents = selectedDate ? sampleEvents[selectedDate] || [] : [];

  return (
    <>
      <div className="p-5 rounded-2xl border border-colordark/[0.06] relative flex flex-col">
      <div className="flex items-center justify-between mb-4">
        {/* Month Selector */}
        <div className="relative">
          <button 
            onClick={() => setShowMonthDropdown(!showMonthDropdown)}
            className="flex items-center gap-1.5 text-[0.9375rem] font-semibold text-colordark tracking-[-0.02em] hover:text-colordark/70 transition-colors cursor-pointer"
          >
            {months[month]} {year}
            <ChevronDown size={14} strokeWidth={2.5} className={`text-colordark/25 transition-transform ${showMonthDropdown ? "rotate-180" : ""}`} />
          </button>
          
          {showMonthDropdown && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowMonthDropdown(false)} />
              <div className="absolute top-full left-0 mt-2 w-[180px] bg-colorlight border border-colordark/8 rounded-xl shadow-[0_20px_60px_-10px_rgba(15,15,12,0.12)] z-20 p-1.5 grid grid-cols-3 gap-0.5">
                {months.map((m, idx) => (
                  <button
                    key={m}
                    onClick={() => setMonth(idx)}
                    className={`text-center px-1 py-2 rounded-lg text-[0.6875rem] font-semibold transition-colors cursor-pointer ${
                      month === idx 
                        ? "bg-colordark text-colorlight" 
                        : "text-colordark/40 hover:bg-colordark/[0.04] hover:text-colordark"
                    }`}
                  >
                    {m.slice(0, 3)}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center gap-1">
          <button onClick={handlePrevMonth} className="w-7 h-7 flex items-center justify-center text-colordark/20 hover:text-colordark/50 hover:bg-colordark/[0.04] rounded-lg transition-all cursor-pointer">
            <ChevronLeft size={15} strokeWidth={2.5} />
          </button>
          <button onClick={handleNextMonth} className="w-7 h-7 flex items-center justify-center text-colordark/20 hover:text-colordark/50 hover:bg-colordark/[0.04] rounded-lg transition-all cursor-pointer">
            <ChevronRight size={15} strokeWidth={2.5} />
          </button>
        </div>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 mb-1.5">
        {dayLabels.map((d, i) => (
          <div key={i} className="text-center text-[0.5625rem] font-bold text-colordark/20 py-1 uppercase tracking-[0.14em]">{d}</div>
        ))}
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-y-0.5">
        {gridCells.map((cell, idx) => {
          const isToday = isCurrentMonth && cell.type === "current" && cell.day === today.getDate();
          const isHighlighted = cell.type === "current" && highlighted.includes(cell.day);
          
          return (
            <div key={idx}
              onClick={() => {
                if (cell.type === "current") {
                  handleDateClick(cell.day);
                }
              }}
              className={`aspect-square flex items-center justify-center text-[0.8125rem] rounded-lg transition-all cursor-pointer font-medium ${
                cell.type !== "current"
                  ? "text-colordark/8 pointer-events-none"
                  : isToday
                  ? "bg-gradient-to-br from-blue-from to-blue-to text-white font-semibold shadow-md shadow-blue-from/20"
                  : isHighlighted
                  ? "text-blue-from font-semibold bg-blue-from/[0.08] hover:bg-blue-from/[0.12]"
                  : "text-colordark/50 hover:bg-colordark/[0.04] hover:text-colordark"
              }`}
            >
              {cell.day}
            </div>
          );
        })}
      </div>
    </div>

    {/* Events Modal */}
    {showEventsModal && (
      <>
        <div className="fixed inset-0 bg-colordark/40 backdrop-blur-sm z-50" onClick={() => setShowEventsModal(false)} />
        <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md bg-white rounded-2xl shadow-2xl z-50 overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-colordark/8">
            <h3 className="text-[1.0625rem] font-semibold text-colordark tracking-[-0.01em]">
              Events for {months[month]} {selectedDate}, {year}
            </h3>
            <button onClick={() => setShowEventsModal(false)} className="p-1.5 text-colordark/40 hover:text-colordark hover:bg-colordark/5 rounded-lg transition-all cursor-pointer">
              <X size={18} strokeWidth={2} />
            </button>
          </div>
          
          <div className="p-6 max-h-[400px] overflow-y-auto">
            {selectedDateEvents.length > 0 ? (
              <div className="space-y-3">
                {selectedDateEvents.map((event) => (
                  <div key={event.id} className="p-4 rounded-xl bg-colordark/[0.02] border border-colordark/[0.06] hover:bg-colordark/[0.04] transition-all">
                    <h4 className="text-[0.9375rem] font-semibold text-colordark mb-2">{event.title}</h4>
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center gap-2 text-[0.8125rem] text-colordark/60">
                        <Clock size={14} strokeWidth={2} className="text-colordark/30" />
                        {event.time}
                      </div>
                      <div className="flex items-center gap-2 text-[0.8125rem] text-colordark/60">
                        <MapPin size={14} strokeWidth={2} className="text-colordark/30" />
                        {event.location}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-[0.9375rem] text-colordark/40">No events scheduled for this day</p>
              </div>
            )}
          </div>
        </div>
      </>
    )}
  </>
  );
}
