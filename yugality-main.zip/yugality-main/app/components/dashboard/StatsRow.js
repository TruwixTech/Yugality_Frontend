"use client";

import { Briefcase, Clock, FileText, Scale, TrendingUp, TrendingDown } from "lucide-react";

const stats = [
  { label: "Active Cases", value: "12", icon: Briefcase, change: "+2", trend: "up" },
  { label: "Pending Tasks", value: "24", icon: Clock, change: "-5", trend: "down" },
  { label: "Documents", value: "148", icon: FileText, change: "+12", trend: "up" },
  { label: "Hearings", value: "3", icon: Scale, change: "0", trend: "neutral" },
];

export default function StatsRow() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, i) => {
        const Icon = stat.icon;
        return (
          <div
            key={i}
            className="group p-5 rounded-2xl border border-colordark/[0.06] hover:border-colordark/[0.12] transition-all duration-200 cursor-default"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-from/10 to-blue-to/10 flex items-center justify-center">
                <Icon size={16} strokeWidth={1.8} className="text-blue-from/70" />
              </div>
              {stat.trend !== "neutral" && (
                <div className={`flex items-center gap-0.5 text-[0.6875rem] font-bold ${
                  stat.trend === "up" ? "text-emerald-500" : "text-rose-500"
                }`}>
                  {stat.trend === "up" ? <TrendingUp size={12} strokeWidth={2.5} /> : <TrendingDown size={12} strokeWidth={2.5} />}
                  <span>{stat.change}</span>
                </div>
              )}
            </div>
            <p className="text-[1.75rem] font-semibold text-colordark tracking-[-0.04em] leading-none mb-1">
              {stat.value}
            </p>
            <p className="text-[0.8125rem] text-colordark/35 font-semibold">{stat.label}</p>
          </div>
        );
      })}
    </div>
  );
}
