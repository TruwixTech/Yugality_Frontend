"use client";

import { Plus, Search, MessageSquare, X } from "lucide-react";

const chatHistory = {
  Today: ["Contract review for Smith case", "Legal precedents on employment law"],
  Yesterday: ["Draft motion to dismiss"],
  "Previous 7 Days": ["Case law research - IP disputes", "Employment contract template", "Discovery motion analysis"],
};

export default function ChatSidebar({ open, onClose }) {
  return (
    <div className={`
      fixed lg:relative inset-y-0 left-0 z-50
      w-[260px] border-r border-colordark/8 bg-colorlight flex flex-col
      transform transition-transform duration-300 ease-in-out
      ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
    `}>
      {/* Header */}
      <div className="px-5 py-5 border-b border-colordark/8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-[0.9375rem] font-semibold text-colordark tracking-[-0.01em]">Chats</h2>
          <button onClick={onClose} className="lg:hidden p-1.5 text-colordark/40 hover:text-colordark hover:bg-colorlight rounded-lg transition-all cursor-pointer">
            <X size={16} strokeWidth={2} />
          </button>
        </div>
        <button className="flex items-center justify-center gap-2 w-full h-9 text-[0.8125rem] font-semibold text-white bg-linear-to-r from-blue-from to-blue-to hover:shadow-[0_4px_15px_-3px_rgba(59,130,246,0.4)] rounded-xl transition-all shadow-sm cursor-pointer">
          <Plus size={14} strokeWidth={2} />
          New Chat
        </button>
      </div>

      {/* Search */}
      <div className="px-4 py-3 border-b border-colordark/8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-colordark/35" size={14} strokeWidth={2} />
          <input
            type="text"
            placeholder="Search chats..."
            className="w-full h-8 pl-8 pr-3 bg-colorlight border border-colordark/8 rounded-lg text-[0.8125rem] text-colordark placeholder:text-colordark/35 focus:outline-none focus:border-colordark/20 transition-colors"
          />
        </div>
      </div>

      {/* History */}
      <div className="flex-1 overflow-y-auto py-2">
        {Object.entries(chatHistory).map(([section, chats]) => (
          <div key={section} className="px-4 py-2">
            <p className="text-[0.625rem] font-bold text-colordark/35 uppercase tracking-wider mb-1.5 px-2">{section}</p>
            <div className="space-y-0.5">
              {chats.map((chat, i) => (
                <button key={i} onClick={onClose}
                  className="flex items-center gap-2.5 w-full px-3 py-2.5 text-left rounded-xl hover:bg-colorlight transition-all group cursor-pointer">
                  <MessageSquare size={14} strokeWidth={2} className="text-colordark/25 shrink-0" />
                  <span className="text-[0.8125rem] font-semibold text-colordark/55 group-hover:text-colordark truncate transition-colors">{chat}</span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
